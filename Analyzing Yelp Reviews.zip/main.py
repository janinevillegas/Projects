#defines text_processing function
def text_processing(text):
    new_text = text.lower()
    new_string = " "
    for letter in new_text:
        if letter.isalpha() == True or letter.isspace() == True:
            new_string += letter
    return new_string.strip() #returns a new string without trailing or leading whitespace


#defines analyze_word function
def analyze_word(word, reviews, scores):
    occurrences = 0
    num_pos = 0
    num_neg = 0
    for i in range(len(reviews)):
        if word in reviews[i]:
            occurrences += 1
            if scores[i] == 1:
                num_pos += 1
            elif scores[i] == 0:
                num_neg += 1
    if num_pos > 0 and num_neg > 0:
        score = round((num_pos / occurrences), 2)
    elif num_pos > 0 and num_neg == 0:
        score = 1.00
    elif num_pos == 0 and num_neg > 0:
        score = 0.00
    elif occurrences == 0:
        score = -1.00
    return score, occurrences #returns score and occurrences


#defines analyze_review function while calling analyze_word()
def analyze_review(review, reviews, scores):
    phrase_list = review.split()
    sum_score = 0
    sum_occurrences = 0
    sum_negative = 0
    for word in phrase_list:
        score, occurrences = analyze_word(word, reviews, scores)
        if score != -1:
            sum_score += score
            sum_occurrences += 1
            avg_score = round(sum_score / sum_occurrences, 2)
        elif score == -1:
            sum_negative += 1
        if sum_negative > sum_occurrences:
            avg_score = -1.00
    return avg_score




if __name__ == '__main__': # Do not remove this line
    #creates empty list for scores and reviews
    scores = []
    reviews = []

    #reads yelp.txt and appends values to lists scores and reviews 
    with open('yelp.txt', 'r') as yelp_file:
        for line in yelp_file:
            scores.append(int(line[0]))
            reviews.append(line[1:].lower().strip())
    


    #starts program
    print('*** Project 03: Analyzing Yelp Review Data ***')
    print()
    print('Please choose one of the following options:')
    print('1 - Analyze Sentiment of Word')
    print('2 - Analyze Sentiment of Review')
    print('0 - Quit')
    user_input = input('Enter option: ')


    #creates invalid statement if user does not enter a digit or 0, 1, 2 
    if user_input.isdigit() == False or int(user_input) > 2 or int(user_input) < 0:
        print('Invalid option. Please try again.')
        print()
        print('Please choose one of the following options:')
        print('1 - Analyze Sentiment of Word')
        print('2 - Analyze Sentiment of Review')
        print('0 - Quit')
        user_input = input('Enter option: ')


    #start of while loop as long as user does not enter 0 (string)
    while user_input != '0':

        #checks to see if user enters a non-digit or a value that is not 0, 1, 2, then prints error message
        if user_input.isdigit() == False or int(user_input) > 2 or int(user_input) < 0:
            print('Invalid option. Please try again.')
            print()
            print('Please choose one of the following options:')
            print('1 - Analyze Sentiment of Word')
            print('2 - Analyze Sentiment of Review')
            print('0 - Quit')
            user_input = input('Enter option: ')
        
        #if user enters a digit that is 0, 1, 2, then this begins the program
        else:
            #starts analysis of a single word as long as user enters 1
            if int(user_input) == 1:
                word_input = input('Enter word: ')

                new_word = text_processing(word_input)
                score, occurrences = analyze_word(new_word, reviews, scores)

                #analyzes the word depending on the score
                if score == -1:
                    print('This word does not appear in the dataset.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')
                elif score > 0.50:
                    print(f'Score: {score:.2f}')
                    print(f'Number of occurrences: {occurrences}')
                    print('This word is positive.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')
                elif score == 0.50:
                    print(f'Score: {score:.2f}')
                    print(f'Number of occurrences: {occurrences}')
                    print('This word is neutral.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')
                elif score < 0.50:
                    print(f'Score: {score:.2f}')
                    print(f'Number of occurrences: {occurrences}')
                    print('This word is negative.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')
            

            #start of review analysis as long as user enters 2
            elif int(user_input) == 2:
                review_input = input('Enter review: ')
                new_review = text_processing(review_input)

                avg_score = analyze_review(new_review, reviews, scores)

                #analyzes the review depending on the average score
                if avg_score > 0.50:
                    print(f'Score: {avg_score:.2f}')
                    print(f'This review is positive.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')
                elif avg_score == 0.50:
                    print(f'Score: {avg_score:.2f}')
                    print(f'This review is neutral.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')
                elif 0.00 <= avg_score < 0.50:
                    print(f'Score: {avg_score:.2f}')
                    print(f'This review is negative.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')
                elif avg_score == -1:
                    print('The words in this review do not appear in the dataset.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Analyze Sentiment of Word')
                    print('2 - Analyze Sentiment of Review')
                    print('0 - Quit')
                    user_input = input('Enter option: ')