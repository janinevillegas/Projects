/*
Halfgammon Undone
Janine Villegas
04/30/2025

Description: This if the file used to create the class functions needed
for a linked list

Notes: This code is a modified version of the FoodNode.cpp file given
from class lecture notes.
*/

#pragma once

#include "HalfGammonBoard.h"

class BoardNode {
private:
    // Uses Halfgammon board
    HalfGammonBoard board;

    // Link for each node
    BoardNode* link;
public:
    // Functions to initialize board and nodes for the linked list
    // Default
    BoardNode();

    // New board without tail end of linked list
    BoardNode(HalfGammonBoard newBoard, BoardNode* newLink);

    // Gets link for the node
    BoardNode* getLink() const;

    // Gets board using Halfgammon board
    HalfGammonBoard getBoard() const;

    // Sets the board using the halfgammon board
    void setBoard(HalfGammonBoard newBoard);

    // Sets the link for the board node
    void setLink(BoardNode* theLink);
};
