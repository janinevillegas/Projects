/*
Halfgammon Undone
Janine Villegas
04/30/2025

Description: This if the file used to create the node functions for the
linked list class.

Notes: This code is a modified version of the FoodNode.cpp file given
from class lecture notes.
*/

#include "BoardList.h"
#include <iostream>
#include <iomanip>

using namespace std;

// Default
BoardNode::BoardNode() {
    this->link = nullptr;
}

// New board function
BoardNode::BoardNode(HalfGammonBoard newBoard, BoardNode* newLink) {
    this->board = newBoard;
    this->link = newLink;
}

// Gets link for the linked list
BoardNode* BoardNode::getLink() const {
    return link;
}

// Return new board
HalfGammonBoard BoardNode::getBoard() const {
    return board;
}

// Sets a new board
void BoardNode::setBoard(HalfGammonBoard newBoard) {
    this->board = newBoard;
}

// Sets link for the board
void BoardNode::setLink(BoardNode* newLink) {
    this->link = newLink;
}

