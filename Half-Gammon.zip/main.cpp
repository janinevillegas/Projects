/*
Halfgammon Undone
Modified By: Janine Villegas
04/30/2025

Description: A modified version of Project 3 (Halfgammon) that adds an undo feature. Along with all the features
in the original version of Halfgammon, the user can use an undo feature to undo the most recent move. This file
contains the "main" game function that handles all gameplay for the user.

Notes: The base code was given for Halfgammon, so small additions were added to implement a linked list to add
the additional undo feature
*/

#include <iostream>
#include <string>
#include "HalfGammonBoard.h"
#include "mersenne-twister.h"
#include "BoardNode.h"
#include "BoardList.h"

using namespace std;

int rollDie();

// Simulates rolling a die, choosing a result 1 to 6
// The seed function must have already been called
// Returns an int, chosen randomly, 1-6
int rollDie() {
	return chooseRandomNumber(1, 6);
}

int main() {
	// Initializes the random number generator with seed from the user
	int randSeed;
	cout << "Enter seed: ";
	cin >> randSeed;
	seed(randSeed);

	// Repeat, allows user to play multiple games
	string keepPlaying;
	do {
		// Game board used to keep track of the current game
		HalfGammonBoard board;

        // List to keep track of previous game board
        BoardList list;

        // Adds the most recent version of the Halfgammon board to a list
        list.addToEnd(board);

		// Display the board and roll dice
		board.displayBoard();
		int roll = rollDie();
		board.displayRoll(roll);
		while (!board.gameOver()) {
			// If the player has a bumped piece, then they must move that
			if (board.hasBumpedPiece()) {
				cout << "Bumped checker must move." << endl;
				if (!board.isMovePossible(roll)) {
					cout << "No move possible." << endl;
				}
				else {
					board.moveBumpedPiece(roll);
				}
			}
			else {
				// Otherwise they can move any of their pieces
				if (!board.isMovePossible(roll)) {
					// No move is possiible with their roll on the current board
					cout << "No move possible." << endl << endl;
				}
				else {
					string movePositionString;
					bool moveSuccessful;

					// Get move from user, and make that move. Repeat loop until a valid move has been chosen
					cout << "What position would you like to move (Q to quit, U to undo)? ";
					cin >> movePositionString;
					if (movePositionString == "q" || movePositionString == "Q") {
						break;
					}

                    // Feature to ask if the user wants to undo a move
                    else if(movePositionString == "u" || movePositionString == "U") {
                        // Checks to see if the user can undo, if cannot returns "cannot undo."
                        if (list.size() <= 1) {
                            cout << "Cannot undo." << endl;
                            continue;
                        }

                        // Undoes the user move, then removes it from the tail end of the linked list
                        board = list.getBoard(list.size() - 2);
                        list.removeFromEnd();

                        // displays new board now that the user "undid" the most recent move
                        board.displayBoard();
                        roll = rollDie();
                        board.displayRoll(roll);
                        continue;
                    }

					int movePosition = stoi(movePositionString);
					moveSuccessful = board.performMove(movePosition, roll);
					if (!moveSuccessful) {
						cout << "Invalid move. Try again." << endl;
						// Continue, so the user can enter input again
						// (this skips changing current player and displaying the board, rolling dice)
						continue;
					}
				}
			}
			// Switch who the current player is
			board.changePlayer();
            if (!board.hasBumpedPiece()) {
                list.addToEnd(board);
            }
            

			if (!board.gameOver()) {
				// Display the board and roll dice
				board.displayBoard();
				roll = rollDie();
				board.displayRoll(roll);
			}
		}

		// If we have left the loop, someone has won--determine whether it's X or O
		if (board.isXWin()) {
			cout << "Player X Wins!" << endl;
		}
		else if (board.isOWin()) {
			cout << "Player O Wins!" << endl;
		}

		cout << endl;
		cout << "Do you want to play again (y/n)? ";
		cin >> keepPlaying;
	} while (tolower(keepPlaying.at(0)) == 'y');
}