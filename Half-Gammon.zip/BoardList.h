/*
Halfgammon Undone
Janine Villegas
04/30/2025

Description: This if the header file used to create the class functions 
for the linked list class.

Notes: This code is a modified version of the FoodList.h file given
from class lecture notes.
*/

#pragma once

#include "BoardNode.h"
#include "HalfGammonBoard.h"

class BoardList {
private:
	// Creates a private variable for the head of the linked list
	BoardNode* head;

public:
	// Default
	BoardList();
	
	// Void function to add to the tail end of the linked list
	void addToEnd(HalfGammonBoard board);

	// Void function to remove tail of linked list
	void removeFromEnd();

	// Get board function
	HalfGammonBoard getBoard(int index);

	// Gets size of the board
	int size();
};