/*
Halfgammon Undone
Janine Villegas
04/30/2025

Description: This if the file used to create the class functions for the
linked list class.

Notes: This code is a modified version of the FoodList.cpp file given
from class lecture notes.
*/

#include "BoardList.h"
#include <iostream>
#include <iomanip>

using namespace std;

// Default constructor
BoardList::BoardList() {
	head = nullptr;
}

// Function to add the Halfgammon board to the tail end of a linked list
void BoardList::addToEnd(HalfGammonBoard board) {
	if (head == nullptr) {
		BoardNode* newNode = new BoardNode(board, head);
		head = newNode;
		return;
	}

	BoardNode* lastNode = head;
	while (lastNode->getLink() != nullptr) {
		lastNode = lastNode->getLink();
	}

	BoardNode* newNode = new BoardNode(board, nullptr);
	lastNode->setLink(newNode);
}

// Removes the tail end of the linked list
void BoardList::removeFromEnd() {
	BoardNode* current = head;
	BoardNode* prev = nullptr;

	while (current->getLink() != nullptr) {
		prev = current;
		current = current->getLink();
	}

	switch (prev == nullptr) {
        case true:
            head = nullptr;
            break;
        case false:
            prev->setLink(nullptr);
            break; 
	}
	delete current;
}

// Returns the new board
HalfGammonBoard BoardList::getBoard(int index) {
	BoardNode* current = head;

	for (int i = 0; i < index; i++) {
		current = current->getLink();
	}

	return current->getBoard();
}

// Returns size of the board
int BoardList::size() {
	BoardNode* current = head;
	int size = 0;
	while (current != nullptr) {
		size++;
		current = current->getLink();
	}

	return size;
}
