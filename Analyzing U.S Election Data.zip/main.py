import driver
STATE_NAMES = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"]


#function from milestone #1
def get_state_winner(state, year):
    election_results = driver.get_election_results(state, year)
    if state not in STATE_NAMES:
        return -1
    elif year % 4 != 0:
        return -1
    else:
        if election_results['Democrat'] > election_results['Republican']:
            winner = 'Democrat'
        else:
            winner = 'Republican'
        num_votes = election_results[winner]
        percentage = (election_results[winner] / (election_results['Democrat'] + election_results['Republican'] + election_results['Other'])) * 100
        return winner, num_votes, percentage


#function from milestone #2
def get_electoral_college_winner(year):
    num_dem_votes = 0
    num_rep_votes = 0
    num_electoral_votes = 0
    for name_state in STATE_NAMES:
        electoral_data = driver.get_electoral_votes(name_state, year)
        state_winner, num_votes, percentage = get_state_winner(name_state, year)
        if state_winner == 'Democrat':
            num_dem_votes += electoral_data
        else:
            num_rep_votes += electoral_data
    if num_dem_votes > num_rep_votes:
        num_electoral_votes += num_dem_votes
        electoral_winner = 'Democrat'
    else:
        num_electoral_votes += num_rep_votes
        electoral_winner = 'Republican'
    percentage = (num_electoral_votes / 538) * 100
    return electoral_winner, num_electoral_votes, percentage


#function from milestone #3
def get_popular_vote_winner(year):
    total_dems_vote = 0
    total_reps_vote = 0
    total_other_vote = 0
    winners_votes = 0
    for state_name in STATE_NAMES:
        election_results = driver.get_election_results(state_name, year)
        total_dems_vote += election_results['Democrat']
        total_reps_vote += election_results['Republican']
        total_other_vote += election_results['Other']
    if total_dems_vote > total_reps_vote:
        winner = 'Democrat'
        winners_votes += total_dems_vote
    else:
        winner = 'Republican'
        winners_votes += total_reps_vote
    percentage = (winners_votes / (total_dems_vote + total_reps_vote + total_other_vote)) * 100
    return winner, winners_votes, percentage



if __name__ == '__main__': # Do not remove this line
    #prints original screen
    print('*** Project 02: Analyzing U.S. Election Data ***')
    print()
    print('Please choose one of the following options:')
    print('1 - Get Election Results by State')
    print('2 - Get Election Results by Electoral College')
    print('3 - Get Election Results by Popular Vote')
    print('0 - Quit')
    user_input = int(input('Enter option: '))


    #runs code as long as user does not quit program
    while user_input != 0:


        #when user enters 1
        if user_input == 1:
            year_input = int(input('Enter year: '))
            state_input = ' '
            if (1976 <= year_input <= 2020) and (year_input % 4 == 0):
                state_input = input('Enter state name: ')
                if state_input not in STATE_NAMES:
                    print('Invalid state name. Please try again.')
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Get Election Results by State')
                    print('2 - Get Election Results by Electoral College')
                    print('3 - Get Election Results by Popular Vote')
                    print('0 - Quit')
                    user_input = int(input('Enter option: '))
                else:
                    name_winner, win_num_votes, percent_won = get_state_winner(state_input, year_input)
                    print(f"Winner: {name_winner}")
                    print(f"Votes: {win_num_votes:,}")
                    print(f"Percentage: {percent_won:.2f}%")
                    print()
                    print('Please choose one of the following options:')
                    print('1 - Get Election Results by State')
                    print('2 - Get Election Results by Electoral College')
                    print('3 - Get Election Results by Popular Vote')
                    print('0 - Quit')
                    user_input = int(input('Enter option: '))
            else:
                print('Invalid year. Please try again.')
                print()
                print('Please choose one of the following options:')
                print('1 - Get Election Results by State')
                print('2 - Get Election Results by Electoral College')
                print('3 - Get Election Results by Popular Vote')
                print('0 - Quit')
                user_input = int(input('Enter option: '))
        
        
        #when user enter 2
        elif user_input == 2:
            year_input = int(input('Enter year: '))
            if (year_input % 4 == 0) and (1976 <= year_input <= 2020):
                winner_electoral_college, winning_num_votes, winning_percent = get_electoral_college_winner(year_input)
                print(f"Winner: {winner_electoral_college}")
                print(f"Electoral Votes: {winning_num_votes}")
                print(f"Percentage: {winning_percent:.2f}%")
                print()
                print('Please choose one of the following options:')
                print('1 - Get Election Results by State')
                print('2 - Get Election Results by Electoral College')
                print('3 - Get Election Results by Popular Vote')
                print('0 - Quit')
                user_input = int(input('Enter option: '))
            else:
                print('Invalid year. Please try again.')
                print()
                print('Please choose one of the following options:')
                print('1 - Get Election Results by State')
                print('2 - Get Election Results by Electoral College')
                print('3 - Get Election Results by Popular Vote')
                print('0 - Quit')
                user_input = int(input('Enter option: '))
        
        
        #when user enters 3
        elif user_input == 3:
            year_input = int(input('Enter year: '))
            if (year_input % 4 == 0) and (1976 <= year_input <= 2020):
                name_winner, num_votes, percent_won = get_popular_vote_winner(year_input)
                print(f"Winner: {name_winner}")
                print(f"Votes: {num_votes:,}")
                print(f"Percentage: {percent_won:.2f}%")
                print()
                print('Please choose one of the following options:')
                print('1 - Get Election Results by State')
                print('2 - Get Election Results by Electoral College')
                print('3 - Get Election Results by Popular Vote')
                print('0 - Quit')
                user_input = int(input('Enter option: '))
            else:
                print('Invalid year. Please try again.')
                print()
                print('Please choose one of the following options:')
                print('1 - Get Election Results by State')
                print('2 - Get Election Results by Electoral College')
                print('3 - Get Election Results by Popular Vote')
                print('0 - Quit')
                user_input = int(input('Enter option: '))
        
        
        #when user enters a number that is not 1, 2, 3, 0
        else:
            print('Invalid option. Please try again.')
            print()
            print('Please choose one of the following options:')
            print('1 - Get Election Results by State')
            print('2 - Get Election Results by Electoral College')
            print('3 - Get Election Results by Popular Vote')
            print('0 - Quit')
            user_input = int(input('Enter option: '))