"""
    driver.py
    Project 1: Analyzing U.S. Data by County
    Copyright © 2024 Gonzalo Bello. All rights reserved.
"""

import pandas as pd # import library
data = pd.read_csv("us_county_data.csv") # load dataset

def get_data_state(state):
    """Returns data for given state"""
    result = data[(data["State"] == state)] # get data for given state
    result = result.drop(['ID', 'State'], axis=1) # remove unnecessary columns
    if result.shape[0] == 0: # if given state is not in dataset
        return -1
    else:
        return result.to_dict('list') # returns data as dictionary

def get_data_county(state, county):
    """Returns data for given state and county"""
    result = data[(data["State"] == state) & (data["County"] == county)] # get data for given county
    result = result.drop(['ID', 'State', 'County'], axis=1) # remove unnecessary columns
    if result.shape[0] == 0: # if given county is not in dataset
        return -1
    else:
        return result.to_dict('records')[0] # returns data as dictionary

def get_name_county(uin):
    """Returns state and county name for given UIN"""
    num_counties = data.shape[0]
    index = int(uin) % num_counties # get index of county for given UIN
    result = data.loc[index, ['State', 'County']]
    return result.to_dict() # returns dictionary with state and county name