import driver
NATIONAL_UNEMPLOYEMENT_RATE = 4.3 # national unemployment rate
NATIONAL_PERCENT_BELOW_POVERTY_LEVEL = 12.5 # national percentage of population below poverty level
NATIONAL_PERCENT_HIGH_SCHOOL = 89.8 # national percentage of population 25 years and over with high school graduate or higher
NATIONAL_PERCENT_BACHELOR = 36.2 # national percentage of population 25 years and over with bachelor's degree or higher

#basic menu that is first shown
print("*** Project 01: Analyzing U.S. County Data ***")
print()
print('Please choose one of the following options:')
print('1 - Analyze Data by County')
print('2 - Analyze Data by State')
print('0 - Quit')
user_input = int(input('Enter option: '))


#start of while loop as long as user_input is not zero
while user_input != 0:


    #start if user entrs 1
    if user_input == 1:
        #basic user input statements if user enters 1
        state = input('Enter state name: ')
        county = input('Enter county name: ')
        county_data = driver.get_data_county(state, county)


        #prints invalid statement if state or county name does not exist
        if county_data == -1:
            print('Invalid state or county name. Please try again.')
            print()
            print('Please choose one of the following options:')
            print('1 - Analyze Data by County')
            print('2 - Analyze Data by State')
            print('0 - Quit')
            user_input = int(input('Enter option: '))
        
        #continues if state or county name exists
        else:
            #math used for later percentages of county data
            percent_female = (county_data['Female'] / county_data['Population']) * 100 
            percent_male = (county_data['Male'] / county_data['Population']) * 100
            percent_computers = (county_data['Households_computer'] / county_data['Households']) * 100
            percent_internet = (county_data['Households_broadband_Internet'] / county_data['Households']) * 100
            

            #prints basic state & county info
            print(f"State: {state}")
            print(f"County: {county}")
            print(f"The population in {county} County, {state} is {county_data['Population']:,}.")
            
            #prints if female population is greater
            if percent_female > percent_male:
                print(f"{percent_female:.2f}% of the population is female.")
            #prints if male population is greater
            else:
                print(f"{percent_male:.2f}% of the population is male.")
            
            #prints household income info
            print(f"The median household income is ${county_data['Median_household_income']:,}.")
            print(f"The mean household income is ${county_data['Mean_household_income']:,}.")
            
            #prints if county has an unemployment rate above national unemployment rate
            if county_data['Unemployment_rate'] > NATIONAL_UNEMPLOYEMENT_RATE:
                print(f"The unemployment rate is {county_data['Unemployment_rate']:.2f}%, which is above the national average.")
            #prints if county has an unemployment rate below the national unemployment rate
            else:
                print(f"The unemployment rate is {county_data['Unemployment_rate']:.2f}%, which is below the national average.")
            
            #prints poverty level info if above national average
            if county_data['Percent_below_poverty_level'] > NATIONAL_PERCENT_BELOW_POVERTY_LEVEL:
                print(f"The percentage of the population below the poverty level is {county_data['Percent_below_poverty_level']:.2f}%, which is above the national average.")
            #prints poverty level info if below national average
            else:
                print(f"The percentage of the population below the poverty level is {county_data['Percent_below_poverty_level']:.2f}%, which is below the national average.")
            
            #prints percentage of population with high school diploma or higher if above national average
            if county_data['Percent_high_school_or_higher'] > NATIONAL_PERCENT_HIGH_SCHOOL:
                print(f"The percentage of the population 25 years and over with a high school diploma or higher is {county_data['Percent_high_school_or_higher']:.2f}%, which is above the national average.")
            
            #prints percentage of population with high school diploma or below if above national average
            else:
                print(f"The percentage of the population 25 years and over with a high school diploma or higher is {county_data['Percent_high_school_or_higher']:.2f}%, which is below the national average.")
            
            #prints household & computer info
            print(f"There are {county_data['Households']:,} households in {county} County, {state}.")
            print(f"{percent_computers:.2f}% of these households have a computer and {percent_internet:.2f}% have a broadband Internet subscription.")
            
            #back to menu
            print()
            print('Please choose one of the following options:')
            print('1 - Analyze Data by County')
            print('2 - Analyze Data by State')
            print('0 - Quit')
            user_input = int(input('Enter option: '))
    

    #starts if user enters 2
    elif user_input == 2:
        state = input('Enter state name: ')
        state_data = driver.get_data_state(state)


        #prints invalid statement if state name does not exist
        if state_data == -1:
            print('Invalid state name. Please try again.')
            print()
            print('Please choose one of the following options:')
            print('1 - Analyze Data by County')
            print('2 - Analyze Data by State')
            print('0 - Quit')
            user_input = int(input('Enter option: '))
        
        #continues if state name exists
        else:
            mean_population = round(sum(state_data['Population']) / len(state_data['County']))
            mean_median_household_income = round(sum(state_data['Median_household_income']) / len(state_data['Median_household_income']))
            mean_unemployment_rate = sum(state_data['Unemployment_rate']) / len(state_data['Unemployment_rate'])
            
            
            #prints state name & number of counties in state
            print(f"State: {state}")
            print(f"There are {len(state_data['County'])} counties in {state}.")
            
            #prints mean, max, and min population in state
            print(f"The mean population in {state} counties is {mean_population:,}.")
            print(f"The maximum population in {state} counties is {max(state_data['Population']):,}.")
            print(f"The minimum population in {state} counties is {min(state_data['Population']):,}.")
            
            #prints mean, max, and min household income in state
            print(f"The mean median household income in {state} counties is ${mean_median_household_income:,}.")
            print(f"The maximum median household income in {state} counties is ${max(state_data['Median_household_income']):,}.")
            print(f"The minimum median household income in {state} counties is ${min(state_data['Median_household_income']):,}.")
            
            #prints mean, max, and min unemployment rate
            print(f"The mean unemployment rate in {state} counties is {mean_unemployment_rate:.2f}%.")
            print(f"The maximum unemployment rate in {state} counties is {max(state_data['Unemployment_rate']):.2f}%.")
            print(f"The minimum unemployment rate in {state} counties is {min(state_data['Unemployment_rate']):.2f}%.")
            
            #back to menu
            print()
            print('Please choose one of the following options:')
            print('1 - Analyze Data by County')
            print('2 - Analyze Data by State')
            print('0 - Quit')
            user_input = int(input('Enter option: '))
    

    #prints invalid statement if user inputs a value that is not 0, 1, 2
    elif user_input > 2 or user_input < 0:
        print('Invalid option. Please try again.')
        print()
        print('Please choose one of the following options:')
        print('1 - Analyze Data by County')
        print('2 - Analyze Data by State')
        print('0 - Quit')
        user_input = int(input('Enter option: '))