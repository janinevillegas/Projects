/*
Red Light Cameras
Janine Villegas
03/28/2025

Description: To analyze different types of red light camera data, classes were used to analyze based on 
data overview, results by neighborhood, chart by month, and search for cameras. The user can input a their 
own file to analyze, which is loaded onto a class in order to analyze however the user wishes.

Notes: Two different classes were used: CameraRecord and NeighborhoodRecord
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

// main class CameraRecord
class CameraRecord {
    public:
        void SetRecord(string currIntersection, string currAddress, int currCameraNum, string currDate, int currNumViolations, string currNeighborhood) {
            intersection = currIntersection;
            address = currAddress;
            cameraNum = currCameraNum;
            date = currDate;
            numViolations = currNumViolations;
            neighborhood = currNeighborhood;
        }

        string GetIntersection() {
            return intersection;
        }

        string GetAddress() {
            return address;
        }

        int GetCameraNum() {
            return cameraNum;
        }

        string GetDate() {
            return date;
        }

        int GetViolations() {
            return numViolations;
        }

        string GetNeighborhood() {
            return neighborhood;
        }

    private:
        string intersection;
        string address;
        int cameraNum;
        string date;
        int numViolations;
        string neighborhood;
};

// class used to analyze 
class NeighborhoodRecord {
    public:
        void SetData(string name, int cams, int vios) {
            nbhName = name;
            totalCams = cams;
            totalVios = vios;
        }

        string GetNbhName() {
            return nbhName;
        }

        int GetTotalCams() {
            return totalCams;
        }

        int GetTotalVios() {
            return totalVios;
        }
    private:
        string nbhName;
        int totalCams;
        int totalVios;

};

// bool operator to sort based on descending violations
bool operator<(NeighborhoodRecord& a, NeighborhoodRecord& b) {
   return a.GetTotalVios() > b.GetTotalVios();
}

// start of functions
// function to check if cameraID is unique
bool uniqueCamera(vector<int>& cameraList, int cameraNum) {
    unsigned int i;
    for (i = 0; i < cameraList.size(); i++) {
        if (cameraList.at(i) == cameraNum) {
            return false;
        }
    }
    return true;
}

// function to check if string is unique (checks if a neighborhood name, intersection name, etc is unique)
bool uniqueString(vector<string>& stringList, string neighborhood) {
    unsigned int i;
    for (i = 0; i < stringList.size(); i++) {
        if (stringList.at(i) == neighborhood) {
            return false;
        }
    }
    return true;
}


// function to make entire string lowercase
string lowerString(string x) {
    unsigned int i;
    for (i = 0; i < x.length(); i++) {
        x[i] = tolower(x[i]);
    }
    return x;
}



int main() {
    // initializes CameraRecord vector/class
    vector<CameraRecord> recordList;
    CameraRecord currRecord;
    CameraRecord printedDate;
    

    // creates a vector to keep track of unique camera IDs and unique neighborhoods
    vector<int> cameraList;
    vector<string> neighborhoodList;


    // initalizes basic variables to append each value to the CameraRecord class
    string intersection, address, cameraNum, date, numViolations, neighborhood;
    int userInput;
    unsigned int i;


    // asks user to input file
    string fileName;
    cout << "Enter file to use: ";
    cin >> fileName;
    cout << endl;

    // opens file
    ifstream userFile;
    userFile.open(fileName);

    // appends each line to the record vector 
    while (getline(userFile, intersection, ',') && getline(userFile, address, ',') && getline(userFile, cameraNum, ',') && getline(userFile, date, ',') && getline(userFile, numViolations, ',') && getline(userFile, neighborhood)) {
        // changes camID and violations string to integer
        int camNumInt = stoi(cameraNum);
        int violationsNumInt = stoi(numViolations);

        // appends each value to the CameraRecord class
        currRecord.SetRecord(intersection, address, camNumInt, date, violationsNumInt, neighborhood);
        recordList.push_back(currRecord);

        // appends each unique cameraID to its own vector
        if (uniqueCamera(cameraList, camNumInt)) {
            cameraList.push_back(camNumInt);
        }

        // appends each unique neighborhood to its own vector
        if (uniqueString(neighborhoodList, neighborhood)) {
            neighborhoodList.push_back(neighborhood);
        }
        if (userFile.eof()) {
            break;
        }
    }
    

    // original menu
    cout << "Select a menu option:" << endl;
    cout << "  1. Data overview" << endl;
    cout << "  2. Results by neighborhood" << endl;
    cout << "  3. Chart by month" << endl;
    cout << "  4. Search for cameras" << endl;
    cout << "  5. Exit" << endl;
    cout << "Your choice: ";
    cin >> userInput;

    // switch cases to start output
    while (userInput != 5) {
        // Data Overview
        if (userInput == 1) {
            // loop to count total violations, the max amount of violations, the intersection
            int violationCount = 0;
            int maxViolations = 0;
            int maxIndex = 0;
            string maxIntersection = "";
            for (i = 0; i < recordList.size(); i++) {
                currRecord = recordList.at(i);
                violationCount += currRecord.GetViolations();

                // records all max value variables needed
                if (maxViolations < currRecord.GetViolations()) {
                    maxViolations = currRecord.GetViolations();
                    maxIntersection = currRecord.GetIntersection();
                    maxIndex = i;
                }
            }

            // parses through the original date string to format it into M-D-YYYY
            printedDate = recordList.at(maxIndex);
            string dateString = printedDate.GetDate();

            string year = dateString.substr(0, 4);
            string month = dateString.substr(5, dateString.find('-', 5) - 5);
            string day = dateString.substr(dateString.find('-', 5) + 1);

            // output the information the user requested
            cout << "Read file with " << recordList.size() << " records." << endl;
            cout << "There are " << cameraList.size() << " cameras." << endl;
            cout << "A total of " << violationCount << " violations." << endl;
            cout << "The most violations in one day were " << maxViolations << " on " << month << "-" << day << "-" << year << " at " << maxIntersection << endl;

            // prints the menu again
            cout << "Select a menu option:" << endl;
            cout << "  1. Data overview" << endl;
            cout << "  2. Results by neighborhood" << endl;
            cout << "  3. Chart by month" << endl;
            cout << "  4. Search for cameras" << endl;
            cout << "  5. Exit" << endl;
            cout << "Your choice: ";
            cin >> userInput;
        }


        // Results by Neighborhood
        else if (userInput == 2) {
            // inializes NeighborhoodRecord class
            vector<NeighborhoodRecord> nbhList;
            NeighborhoodRecord currList;

            // creates vectors for unique neighborhood names and unique camera IDs
            vector<string> neighborhoodNames;
            vector<int> uniqueCamIDS;

            // appends each unique neighborhood name to the Neighborhood names vector
            for (i = 0; i < recordList.size(); i++) {
                currRecord = recordList.at(i);

                // appends the value
                if (uniqueString(neighborhoodNames, currRecord.GetNeighborhood())) {
                    neighborhoodNames.push_back(currRecord.GetNeighborhood());
                }
            }

            // creates vectors to keep track of the total number of cameras and total violation per neighborhood
            vector<int> camCounts(neighborhoodNames.size(), 0);
            vector<int> viosCounts(neighborhoodNames.size(), 0);

            // loop to append values to vectors above
            for (i = 0; i < recordList.size(); i++) {
                currRecord = recordList.at(i);

                // variables to keep track on each value
                string currName = currRecord.GetNeighborhood();
                int camNum = currRecord.GetCameraNum();
                int numVios = currRecord.GetViolations();

                // loop to update total violations and number of cameras per neighborhood
                for (long unsigned int j = 0; j < neighborhoodNames.size(); j++) {
                    // checks to see if neighborhood name is unique
                    if (currName == neighborhoodNames.at(j)) {
                        // updates total violations per neighborhood
                        viosCounts.at(j) += numVios;

                        // counts each camera per neighborhood
                        if (uniqueCamera(uniqueCamIDS, camNum)) {
                            uniqueCamIDS.push_back(camNum);
                            camCounts.at(j) += 1;
                        }

                    }
                }
            }

            // appends the total cameras, total violations, and neighborhood name to NeighborhoodRecord class
            for (i = 0; i < neighborhoodNames.size(); i++) {
                currList.SetData(neighborhoodNames.at(i), camCounts.at(i), viosCounts.at(i));

                nbhList.push_back(currList);
            }

            // sorts NeighborhoodRecord vector descending
            sort(nbhList.begin(), nbhList.end());

            // prints the values
            for (i = 0; i < nbhList.size(); i++) {
                cout << left << setw(25) << nbhList.at(i).GetNbhName() << right << setw(4) << nbhList.at(i).GetTotalCams() << right << setw(7) << nbhList.at(i).GetTotalVios() << endl;
            }

            // prints the menu again
            cout << "Select a menu option:" << endl;
            cout << "  1. Data overview" << endl;
            cout << "  2. Results by neighborhood" << endl;
            cout << "  3. Chart by month" << endl;
            cout << "  4. Search for cameras" << endl;
            cout << "  5. Exit" << endl;
            cout << "Your choice: ";
            cin >> userInput;
        }


        // Chart by Month
        else if (userInput == 3) {
            // inializes vector to record each month's violations
            vector<int> monthlyViolations(12, 0);

            // loop to update each vector value based on the month
            for (i = 0; i < recordList.size(); i++) {
                currRecord = recordList.at(i);
                string dateString = currRecord.GetDate();

                int month = stoi(dateString.substr(5, dateString.find('-', 5) - 5)) - 1;

                monthlyViolations[month] += currRecord.GetViolations();
                
            }

            // creates variables based on how many violations per month
            int jan = monthlyViolations[0];
            int feb = monthlyViolations[1];
            int mar = monthlyViolations[2];
            int apr = monthlyViolations[3];
            int may = monthlyViolations[4];
            int june = monthlyViolations[5];
            int july = monthlyViolations[6];
            int aug = monthlyViolations[7];
            int sept = monthlyViolations[8];
            int oct = monthlyViolations[9];
            int nov = monthlyViolations[10];
            int dec = monthlyViolations[11];

            // prints chart for each month
            cout << left << setw(15) << "January " << string(jan / 1000, '*') << endl;
            cout << left << setw(15) << "February " << string(feb / 1000, '*') << endl;
            cout << left << setw(15) << "March " << string(mar / 1000, '*') << endl;
            cout << left << setw(15) << "April " << string(apr / 1000, '*') << endl;
            cout << left << setw(15) << "May " << string(may / 1000, '*') << endl;
            cout << left << setw(15) << "June " << string(june / 1000, '*') << endl;
            cout << left << setw(15) << "July " << string(july / 1000, '*') << endl;
            cout << left << setw(15) << "August " << string(aug / 1000, '*') << endl;
            cout << left << setw(15) << "September " << string(sept / 1000, '*') << endl;
            cout << left << setw(15) << "October " << string(oct / 1000, '*') << endl;
            cout << left << setw(15) << "November " << string(nov / 1000, '*') << endl;
            cout << left << setw(15) << "December " << string(dec / 1000, '*') << endl;

            // prints the menu again
            cout << "Select a menu option:" << endl;
            cout << "  1. Data overview" << endl;
            cout << "  2. Results by neighborhood" << endl;
            cout << "  3. Chart by month" << endl;
            cout << "  4. Search for cameras" << endl;
            cout << "  5. Exit" << endl;
            cout << "Your choice: ";
            cin >> userInput;
        }


        // Search for Cameras
        else if (userInput == 4) {
            // makes a second unique camera ID vector
            vector<int> uniqueID;

            // initializes the neighborhood/intersection the user is looking for
            string userName;
            cin.ignore();
            cout << "What should we search for? ";
            getline(cin, userName);

            // changes the input to all lowercase to make an easier comparison
            userName = lowerString(userName);

            // variable to figure out if there are cameras in the search area
            bool doesExist = false;

            // loop to go through all values in the recordd
            for (i = 0; i < recordList.size(); i++) {
                currRecord = recordList.at(i);

                // makes the neighborhood and intersection all lowercase
                string intersectionLower = lowerString(currRecord.GetIntersection());
                string neighborhoodLower = lowerString(currRecord.GetNeighborhood());

                // checks to see if there is a match when searching through records
                if (intersectionLower.find(userName) != string::npos || neighborhoodLower.find(userName) != string::npos) {
                    // appends each unique camera to the vector above
                    if (uniqueCamera(uniqueID, currRecord.GetCameraNum())) {
                        uniqueID.push_back(currRecord.GetCameraNum());

                        // prints required statement
                        cout << "Camera: " << currRecord.GetCameraNum() << endl;
                        cout << "Address: " << currRecord.GetAddress() << endl;
                        cout << "Intersection: " << currRecord.GetIntersection() << endl;
                        cout << "Neighborhood: " << currRecord.GetNeighborhood() << endl;
                        cout << endl;

                        // switches boolean variable
                        doesExist = true;
                    }
                }

            }

            // prints that cameras do not exist
            if (doesExist == false) {
                cout << "No cameras found." << endl;
            }

            // prints the menu again
            cout << "Select a menu option:" << endl;
            cout << "  1. Data overview" << endl;
            cout << "  2. Results by neighborhood" << endl;
            cout << "  3. Chart by month" << endl;
            cout << "  4. Search for cameras" << endl;
            cout << "  5. Exit" << endl;
            cout << "Your choice: ";
            cin >> userInput;

        }

    }
}

